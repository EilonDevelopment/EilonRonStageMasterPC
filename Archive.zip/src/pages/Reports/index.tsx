import React, { FC, useEffect, useState } from "react";
import { IonIcon, IonToggle } from "@ionic/react";
import { useTranslation } from "react-i18next";
import { codeSlashSharp, cubeSharp, documentSharp, downloadSharp, mailSharp, refreshSharp, trashSharp } from "ionicons/icons";
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

import CommonLayout from "../../Layout/CommonLayout";
import useAppData from "../../hooks/useAppData";
import Text from "../../components/Text";
import { IProject } from "../../helper/types";
import { normalizeProjectId } from "../../helper/functions";
import { db } from '../../db'
import Swal from "sweetalert2";
import Spinner from "../../components/Spinner";
import { format, getTime, getUnixTime } from "date-fns"
import { jsPDF } from 'jspdf';
import { EmailComposer } from "@awesome-cordova-plugins/email-composer";
import { toast } from 'react-toastify';
import { renderToString } from 'react-dom/server'
import './index.css';

interface LogFilter {
  ok: boolean;
  overload: boolean;
  danger: boolean;
  underload: boolean;
  err: boolean;
  start: Date;
  end: Date;
}

const Report: FC = () => {
  const { platformType, projects, curProject, lcs, logs, layoutRefreshRef } = useAppData();
  const { t } = useTranslation();

  const [projectList, setProjectList] = useState<IProject[]>([])
  const [selectedId, setSelectedId] = useState<string>('')
  const [filter, setFilter] = useState<LogFilter>({
    ok: false,
    overload: true,
    danger: true,
    underload: true,
    err: false,
    start: new Date(),
    end: new Date(),
  } as LogFilter);
  const [logList, setLogList] = useState<any>(null)
  const [loading, setLoading] = useState<boolean>(false)
  const [loadStatus, setLoadStatus] = useState<boolean>(false)
  const PAGE_SIZE = 10
  const [page, setPage] = useState<number>(1)

  const reportIntervalSeconds = (projects.find(p => normalizeProjectId(p.id) === normalizeProjectId(selectedId))?.report_interval_seconds ?? 60) || 60;

  useEffect(() => {
    if (selectedId) {
      const { ok, overload, danger, underload, err, start, end } = filter;
      load_reports(selectedId, ok, overload, danger, underload, err, start, end, reportIntervalSeconds);
      setLoadStatus(false)
    } else {
      setLogList(null)
    }
  }, [selectedId, filter, loadStatus === true, reportIntervalSeconds])

  // Helper function to merge and deduplicate logs
  const mergeAndDeduplicateLogs = (logArrays: any) => {
    const logMap = new Map();
    logArrays.forEach((logs: any) => {
      logs.forEach((log: any) => {
        if (!logMap.has(log.id)) {
          logMap.set(log.id, log);
        }
      });
    });
    return Array.from(logMap.values());
  }

  const load_reports = (project_id: any, ok: any, overload: any, danger: any, underload: any, trerr: any, fromVal: any, toVal: any, report_interval_seconds = 60) => {
    setLoading(true);

    const from = getTime(new Date(fromVal).setHours(0, 0, 0, 0))
    const to = getTime(new Date(toVal).setHours(23, 59, 59, 999));
    console.log('start', from, to, format(getTime(fromVal), 'yyyy-MM-dd'), format(getTime(toVal), 'yyyy-MM-dd'));

    const pidNorm = normalizeProjectId(project_id);
    const projectMatch = (log: any) => normalizeProjectId(log.project_id) === pidNorm;

    // Define individual queries based on filters (use Number() so DB string/number comparison is reliable)
    const queries = [];
    const hasLogType = (log: any) => log.log_type != null && String(log.log_type).trim() !== '';
    const logType = (log: any) => String(log.log_type).toLowerCase();
    const n = (x: any) => Number(x);
    if (ok) {
      queries.push(db.logs.filter(log =>
        projectMatch(log)
        && log.log_date >= from && log.log_date <= to
        && (hasLogType(log) ? logType(log) === 'ok' : (n(log.value) >= n(log.underload) && n(log.value) <= n(log.overload)))).toArray());
    }
    if (overload) {
      queries.push(db.logs.filter(log => projectMatch(log) && log.log_date >= from && log.log_date <= to && (hasLogType(log) ? logType(log) === 'overload' : n(log.value) > n(log.overload))).toArray());
    }
    if (danger) {
      queries.push(db.logs.filter(log => {
        if (!projectMatch(log) || log.log_date < from || log.log_date > to) return false;
        const isDangerByType = hasLogType(log) && logType(log) === 'danger';
        const isDangerByValue = n(log.overload) > 0 && n(log.value) >= n(log.overload) * 1.3;
        return isDangerByType || isDangerByValue;
      }).toArray());
    }
    if (underload) {
      queries.push(db.logs.filter(log => projectMatch(log) && log.log_date >= from && log.log_date <= to && (hasLogType(log) ? logType(log) === 'underload' : (n(log.value) < n(log.underload) && n(log.value) !== -99999999))).toArray());
    }
    if (trerr) {
      queries.push(db.logs.filter(log => projectMatch(log) && log.log_date >= from && log.log_date <= to && (hasLogType(log) ? logType(log) === 'err' : n(log.value) === -99999999)).toArray());
    }

    // If no filters are selected, use a default query
    if (queries.length === 0) {
      queries.push(db.logs.filter(log => projectMatch(log) && log.log_date >= from && log.log_date <= to).toArray());
    }

    // Execute all queries and merge results
    Promise.all(queries)
      .then(results => mergeAndDeduplicateLogs(results))
      .then(mergedLogs => {
        const isErrLog = (log: any) => (log.log_type != null && String(log.log_type).toLowerCase() === 'err') || Number(log.value) === -99999999;
        const errLogs = mergedLogs.filter((log: any) => isErrLog(log));
        const validLogs = mergedLogs.filter(log => {
          const value = parseFloat(log.value);
          const realval = parseFloat(log.realval);
          return !isNaN(value) && !isNaN(realval);
        });
        if (validLogs.length > 0) {
          const intervalMs = Math.max(1000, (report_interval_seconds || 60) * 1000);
          const groups: any = {};
          validLogs.forEach(log => {
            const intervalStart = Math.floor(Number(log.log_date) / intervalMs) * intervalMs;
            const key = format(new Date(intervalStart), "yyyy-MM-dd HH:mm:ss");
            groups[key] = groups[key] || [];
            groups[key].push(log);
          });
          setLogList(groups)
          setPage(1)
        } else
          setLogList(null)

        setLoading(false)
      })
      .catch(error => {
        console.error('Error generating report: ' + error);
        setLoading(false)
      });
  }

  const ExportList = [
    { title: t('Report.Email'), icon: mailSharp, hidden: true },
    { title: t('Report.CSV'), icon: downloadSharp },
    { title: t('Report.JSON'), icon: codeSlashSharp, hidden: true },
    { title: t('Report.SQL'), icon: cubeSharp, hidden: true },
    { title: t('Report.PDF'), icon: documentSharp },
  ]

  const draw_report_table = () => {
    console.log("===draw_report_table===")
  }

  const ReportTable = () => {
    if (!logList || loading) return null
    const intervalKeys = (Object.keys(logList) as string[]).sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
    const totalIntervals = intervalKeys.length
    const totalPages = Math.max(1, Math.ceil(totalIntervals / PAGE_SIZE))
    const currentPage = Math.min(page, totalPages)
    const start = (currentPage - 1) * PAGE_SIZE
    const paginatedKeys = intervalKeys.slice(start, start + PAGE_SIZE)
    const paginatedByDate: Record<string, any[]> = {}
    paginatedKeys.forEach((key) => {
      const logs = [...(logList[key] || [])]
      logs.sort((a: any, b: any) => (String(a.lc_id || '')).localeCompare(String(b.lc_id || '')) || (a.log_date || 0) - (b.log_date || 0))
      paginatedByDate[key] = logs
    })

    return (
      <div className="w-full pb-5">
        {paginatedKeys.map((key, index) => (
          <div key={index} className="my-2">
            <Text classes="flex bg-primary text-white py-1 px-3" label={key} />
            <table className="table-auto w-full border-collapse border border-slate-400">
              <thead>
                <tr className="text-left">
                  <th className="border border-slate-300 text-dark dark:text-white px-3 py-1 font-medium ">{t("Report.Title")}</th>
                  <th className="border border-slate-300 text-dark dark:text-white px-3 py-1 font-medium ">{t("Report.ID")}</th>
                  <th className="border border-slate-300 text-dark dark:text-white px-3 py-1 font-medium w-28">{t("Report.Load")}</th>
                  <th className="border border-slate-300 text-dark dark:text-white px-3 py-1 font-medium w-28">{t("Report.Battery")}</th>
                  <th className="border border-slate-300 text-dark dark:text-white px-3 py-1 font-medium w-48">{t("Report.Time")}</th>
                </tr>
              </thead>
              <tbody>
                {paginatedByDate[key].map((sItem: any, sKey: any) => {
                  const lc = lcs.find((cItem: any) => cItem.id === sItem.lc_id?.toString());
                  const isTrErr = (sItem.log_type != null && String(sItem.log_type).toLowerCase() === 'err') || Number(sItem.value) === -99999999;
                  const displayLoad = isTrErr ? 'Tr.Err' : `${sItem.value ?? ''} ${sItem.unit ?? ''}`.trim();
                  return (
                    <tr key={sKey} className="w-full">
                      <td className="border border-slate-300 text-dark dark:text-white px-3 py-1">{lc?.title}</td>
                      <td className="border border-slate-300 text-dark dark:text-white px-3 py-1">{lc?.id}</td>
                      <td className="border border-slate-300 text-dark dark:text-white px-3 py-1">{displayLoad}</td>
                      <td className="border border-slate-300 text-dark dark:text-white px-3 py-1">{formatBattery(sItem.battery)}</td>
                      <td className="border border-slate-300 text-dark dark:text-white px-3 py-1">{format(sItem.log_date, "yyyy-MM-dd pp")}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        ))}
        {totalIntervals > PAGE_SIZE && (
          <div className="flex flex-row items-center justify-between gap-4 py-2 mt-2 border-t border-slate-300">
            <span className="text-dark dark:text-light">
              {PAGE_SIZE} {t("Report.IntervalsPerPage") || "intervals per page"} · {start + 1}-{Math.min(start + PAGE_SIZE, totalIntervals)} {t("Report.Of") || "of"} {totalIntervals}
            </span>
            <div className="flex flex-row items-center gap-2">
              <button
                type="button"
                className="px-3 py-1 rounded border border-slate-400 disabled:opacity-50"
                disabled={currentPage <= 1}
                onClick={() => setPage(p => Math.max(1, p - 1))}
              >
                ‹
              </button>
              <span className="text-dark dark:text-light">{currentPage} / {totalPages}</span>
              <button
                type="button"
                className="px-3 py-1 rounded border border-slate-400 disabled:opacity-50"
                disabled={currentPage >= totalPages}
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              >
                ›
              </button>
            </div>
          </div>
        )}
      </div>
    )
  }

  useEffect(() => {
    setProjectList(projects)
    if (projects.length > 0) {
      const curId = curProject?.id != null ? normalizeProjectId(curProject.id) : ''
      const curInList = curId && projects.some((p: IProject) => normalizeProjectId(p.id) === curId)
      setSelectedId((prev) => {
        const prevInList = prev && projects.some((p: IProject) => normalizeProjectId(p.id) === prev)
        if (!prevInList && curInList) return curId
        if (!prevInList) return normalizeProjectId(projects[0].id)
        return prev
      })
    } else {
      setSelectedId('')
    }
  }, [projects, curProject?.id])

  useEffect(() => {
    if (!logList) return
    const totalIntervals = (Object.keys(logList) as string[]).length
    const totalPages = Math.max(1, Math.ceil(totalIntervals / PAGE_SIZE))
    if (page > totalPages) setPage(totalPages)
  }, [logList, page])

  useEffect(() => {
    console.log('filter data: ', filter)
  }, [filter])

  const getAllLogsFromList = (): any[] => {
    if (!logList || typeof logList !== 'object') return [];
    return (Object.keys(logList) as string[])
      .flatMap((key) => logList[key] || [])
      .sort((a: any, b: any) => (b.log_date || 0) - (a.log_date || 0));
  };

  const formatLogLoad = (log: any) => {
    const isErr = (log.log_type != null && String(log.log_type).toLowerCase() === 'err') || Number(log.value) === -99999999;
    return isErr ? 'Tr.Err' : `${log.value ?? ''} ${log.unit ?? ''}`.trim();
  };

  /** One row per log, same as example.js: Unit (title or id), Load, Battery, Time */
  const formatBattery = (b: any) => {
    if (b == null || String(b).trim() === '') return '';
    return `${String(b).trim()}%`;
  };
  const getReportRows = (data: any[]) =>
    data.map((log: any) => {
      const lc = lcs.find((c: any) => c.id === log.lc_id?.toString());
      return {
        Unit: (lc?.title || log.lc_id || '').toString(),
        Load: formatLogLoad(log),
        Battery: formatBattery(log.battery),
        Time: format(new Date(log.log_date), 'yyyy-MM-dd HH:mm:ss'),
      };
    });

  const openMailtoFallback = (subject: string, logData: any[]) => {
    const project = projects.find(p => normalizeProjectId(p.id) === normalizeProjectId(selectedId));
    const reportRows = getReportRows(logData);
    const lines = reportRows.slice(0, 50).map((r) => `${r.Unit}\t${r.Load}\t${r.Battery}\t${r.Time}`);
    const body = `Report: ${project?.title ?? ''}\nDate range: ${format(new Date(filter.start), 'yyyy-MM-dd')} – ${format(new Date(filter.end), 'yyyy-MM-dd')}\nTotal rows: ${logData.length}\n\nUnit\tLoad\tBattery\tTime\n${lines.join('\n')}${logData.length > 50 ? '\n...' : ''}`;
    const mailto = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailto;
  };

  const androidDeferredAfterIntent = (successMessage: string) => {
    requestAnimationFrame(() => {
      setTimeout(() => {
        try {
          void document.body.offsetHeight;
          window.dispatchEvent(new Event('resize'));
          toast.success(successMessage);
          if (typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
          layoutRefreshRef.current?.();
        } catch (e) {
          if (typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
        }
      }, 400);
    });
  };

  const ANDROID_EXPORT_PREPARING_TOAST_ID = 'report-android-export-preparing';
  const ANDROID_EXPORT_TIMEOUT_MS = 60000; // 60s
  const MAX_ANDROID_PDF_ROWS = 1500; // Limit PDF size on Android so export finishes in seconds

  const runAndroidExport = (fn: () => Promise<void>) => {
    toast.info(t('Report.PreparingExport') || 'Preparing export...', { toastId: ANDROID_EXPORT_PREPARING_TOAST_ID });
    requestAnimationFrame(() => {
      setTimeout(() => {
        const timeoutPromise = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('Export timeout')), ANDROID_EXPORT_TIMEOUT_MS)
        );
        Promise.race([fn(), timeoutPromise])
          .then(() => {
            toast.dismiss(ANDROID_EXPORT_PREPARING_TOAST_ID);
          })
          .catch((err) => {
            toast.dismiss(ANDROID_EXPORT_PREPARING_TOAST_ID);
            if (typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
            console.error('[Report Export] Error:', err);
            const isTimeout = err?.message === 'Export timeout';
            Swal.fire({
              title: t('Report.Export') || 'Export',
              text: isTimeout ? (t('Report.ExportTimeout') || 'Export took too long. Try a smaller date range or try again.') : (t('Report.ExportError') || 'Failed to export.'),
              icon: 'error',
            });
          });
      }, 50);
    });
  };

  const handleExport = async (type: string) => {
    const logData = getAllLogsFromList();

    if (logData.length === 0) {
      Swal.fire({
        title: t('Report.Export') || 'Export',
        text: t('Report.NoDataToExport') || 'No data to export. Load a report first.',
        icon: 'info',
        heightAuto: false,
      });
      console.log('[Report Export] No data to export');
      return;
    }

    switch (type) {
      case t('Report.CSV'): {
        try {
          const project = projects.find(p => normalizeProjectId(p.id) === normalizeProjectId(selectedId));
          const escapeCsv = (v: any) => {
            const s = v == null ? '' : String(v);
            if (/[",\r\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
            return s;
          };
          const reportRows = getReportRows(logData);
          const rows: string[] = ['Unit,Load,Battery,Time'];
          reportRows.forEach((r) => rows.push([r.Unit, r.Load, r.Battery, r.Time].map(escapeCsv).join(',')));
          const csvStr = rows.join('\r\n');
          const fileName = `report_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.csv`;

          if (platformType === 'web') {
            const blob = new Blob(['\uFEFF' + csvStr], { type: 'text/csv;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            a.click();
            URL.revokeObjectURL(url);
          } else if (platformType === 'android') {
            await Filesystem.writeFile({ path: fileName, data: '\uFEFF' + csvStr, directory: Directory.Cache, encoding: Encoding.UTF8 });
            const { uri } = await Filesystem.getUri({ path: fileName, directory: Directory.Cache });
            if (typeof sessionStorage !== 'undefined') sessionStorage.setItem('skipResumeAlert', '1');
            await Share.share({ url: uri, title: t('Report.Export') || 'Export', dialogTitle: t('Report.Export') || 'Export' });
            androidDeferredAfterIntent(`${t('Report.ExportSuccess') || 'Export success'} (${logData.length} logs).`);
          } else {
            await Filesystem.writeFile({ path: fileName, data: '\uFEFF' + csvStr, directory: Directory.Documents, encoding: Encoding.UTF8 });
            Swal.fire({ title: t('Report.Export') || 'Export', text: `${t('Report.ExportSuccess')} (${logData.length} logs).`, icon: 'success' });
          }
        } catch (err) {
          if (platformType === 'android' && typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
          console.error('[Report Export] CSV export error:', err);
          Swal.fire({
            title: t('Report.Export') || 'Export',
            text: t('Report.ExportError') || 'Failed to export CSV.',
            icon: 'error',
          });
        }
        break;
      }
      case t('Report.JSON'): {
        if (platformType === 'android') {
          runAndroidExport(async () => {
            try {
              const reportRows = getReportRows(logData);
              const jsonStr = JSON.stringify(reportRows, null, 2);
              const fileName = `report_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.json`;
              await Filesystem.writeFile({ path: fileName, data: jsonStr, directory: Directory.Cache, encoding: Encoding.UTF8 });
              const { uri } = await Filesystem.getUri({ path: fileName, directory: Directory.Cache });
              if (typeof sessionStorage !== 'undefined') sessionStorage.setItem('skipResumeAlert', '1');
              await Share.share({ url: uri, title: t('Report.Export') || 'Export', dialogTitle: t('Report.Export') || 'Export' });
              androidDeferredAfterIntent(`${t('Report.ExportSuccess') || 'Export success'} (${logData.length} logs).`);
            } catch (err) {
              if (typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
              console.error('[Report Export] JSON export error:', err);
              Swal.fire({ title: t('Report.Export') || 'Export', text: t('Report.ExportError') || 'Failed to export JSON.', icon: 'error' });
            }
          });
          break;
        }
        try {
          const reportRows = getReportRows(logData);
          const jsonStr = JSON.stringify(reportRows, null, 2);
          const fileName = `report_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.json`;
          if (platformType === 'web') {
            const blob = new Blob([jsonStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            a.click();
            URL.revokeObjectURL(url);
          } else {
            await Filesystem.writeFile({ path: fileName, data: jsonStr, directory: Directory.Documents, encoding: Encoding.UTF8 });
            Swal.fire({ title: t('Report.Export') || 'Export', text: `${t('Report.ExportSuccess')} (${logData.length} logs).`, icon: 'success' });
          }
        } catch (err) {
          console.error('[Report Export] JSON export error:', err);
          Swal.fire({ title: t('Report.Export') || 'Export', text: t('Report.ExportError') || 'Failed to export JSON.', icon: 'error' });
        }
        break;
      }
      case t('Report.SQL'): {
        if (platformType === 'android') {
          runAndroidExport(async () => {
            try {
              const reportRows = getReportRows(logData);
              const escape = (v: any) => {
                const s = String(v ?? '').replace(/'/g, "''");
                return `'${s}'`;
              };
              const lines: string[] = reportRows.map(
                (r) => `INSERT INTO logs (\`Unit\`,\`Load\`,\`Battery\`,\`Time\`) VALUES (${escape(r.Unit)},${escape(r.Load)},${escape(r.Battery)},${escape(r.Time)});`
              );
              const sqlStr = lines.join('\n');
              const fileName = `report_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.sql`;
              await Filesystem.writeFile({ path: fileName, data: sqlStr, directory: Directory.Cache, encoding: Encoding.UTF8 });
              const { uri } = await Filesystem.getUri({ path: fileName, directory: Directory.Cache });
              if (typeof sessionStorage !== 'undefined') sessionStorage.setItem('skipResumeAlert', '1');
              await Share.share({ url: uri, title: t('Report.Export') || 'Export', dialogTitle: t('Report.Export') || 'Export' });
              androidDeferredAfterIntent(`${t('Report.ExportSuccess') || 'Export success'} (${logData.length} logs).`);
            } catch (err) {
              if (typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
              console.error('[Report Export] SQL export error:', err);
              Swal.fire({ title: t('Report.Export') || 'Export', text: t('Report.ExportError') || 'Failed to export SQL.', icon: 'error' });
            }
          });
          break;
        }
        try {
          const reportRows = getReportRows(logData);
          const escape = (v: any) => {
            const s = String(v ?? '').replace(/'/g, "''");
            return `'${s}'`;
          };
          const lines: string[] = reportRows.map(
            (r) => `INSERT INTO logs (\`Unit\`,\`Load\`,\`Battery\`,\`Time\`) VALUES (${escape(r.Unit)},${escape(r.Load)},${escape(r.Battery)},${escape(r.Time)});`
          );
          const sqlStr = lines.join('\n');
          const fileName = `report_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.sql`;
          if (platformType === 'web') {
            const blob = new Blob([sqlStr], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            a.click();
            URL.revokeObjectURL(url);
          } else {
            await Filesystem.writeFile({ path: fileName, data: sqlStr, directory: Directory.Documents, encoding: Encoding.UTF8 });
            Swal.fire({ title: t('Report.Export') || 'Export', text: `${t('Report.ExportSuccess')} (${logData.length} logs).`, icon: 'success' });
          }
        } catch (err) {
          console.error('[Report Export] SQL export error:', err);
          Swal.fire({ title: t('Report.Export') || 'Export', text: t('Report.ExportError') || 'Failed to export SQL.', icon: 'error' });
        }
        break;
      }
      case t('Report.PDF'): {
        if (platformType === 'android') {
          runAndroidExport(async () => {
            try {
              const totalRows = logData.length;
              const capped = totalRows > MAX_ANDROID_PDF_ROWS;
              const rowsForPdf = capped ? getReportRows(logData).slice(0, MAX_ANDROID_PDF_ROWS) : getReportRows(logData);
              const project = projects.find(p => normalizeProjectId(p.id) === normalizeProjectId(selectedId));
              const doc = new jsPDF('p', 'mm', 'a4');
              const pageW = doc.internal.pageSize.getWidth();
              const margin = 10;
              const colWidths = [50, 40, 35, 52];
              const rowHeight = 7;
              let y = margin;
              doc.setFontSize(14);
              doc.text(t('Report.Export') || 'Report', margin, y);
              y += 10;
              doc.setFontSize(10);
              if (project) doc.text(`${t('Report.MyProjects') || 'Project'}: ${project.title}`, margin, y);
              y += 6;
              doc.text(`${format(new Date(filter.start), 'yyyy-MM-dd')} – ${format(new Date(filter.end), 'yyyy-MM-dd')}`, margin, y);
              y += 10;
              const headers = ['Unit', t('Report.Load'), t('Report.Battery'), t('Report.Time')];
              doc.setFontSize(8);
              doc.setFillColor(240, 240, 240);
              doc.rect(margin, y, pageW - 2 * margin, rowHeight, 'F');
              headers.forEach((h, i) => {
                doc.text(h, margin + (i === 0 ? 2 : colWidths.slice(0, i).reduce((a, b) => a + b, 0) + 2), y + 5);
              });
              doc.setDrawColor(200, 200, 200);
              let colX = margin;
              colWidths.forEach((w) => { doc.line(colX, y, colX, y + rowHeight); colX += w; });
              doc.line(margin, y + rowHeight, pageW - margin, y + rowHeight);
              y += rowHeight;
              const maxY = doc.internal.pageSize.getHeight() - margin;
              for (let i = 0; i < rowsForPdf.length; i++) {
                if (y + rowHeight > maxY) {
                  doc.addPage();
                  y = margin;
                  doc.setFillColor(240, 240, 240);
                  doc.rect(margin, y, pageW - 2 * margin, rowHeight, 'F');
                  headers.forEach((h, ii) => {
                    doc.text(h, margin + (ii === 0 ? 2 : colWidths.slice(0, ii).reduce((a, b) => a + b, 0) + 2), y + 5);
                  });
                  colX = margin;
                  colWidths.forEach((w) => { doc.line(colX, y, colX, y + rowHeight); colX += w; });
                  doc.line(margin, y + rowHeight, pageW - margin, y + rowHeight);
                  y += rowHeight;
                }
                const r = rowsForPdf[i];
                const row = [r.Unit.slice(0, 24), r.Load.slice(0, 14), r.Battery.slice(0, 8), r.Time.slice(0, 19)];
                row.forEach((cell, ii) => {
                  doc.text(cell, margin + (ii === 0 ? 2 : colWidths.slice(0, ii).reduce((a, b) => a + b, 0) + 2), y + 5);
                });
                colX = margin;
                colWidths.forEach((w) => { doc.line(colX, y, colX, y + rowHeight); colX += w; });
                doc.line(margin, y + rowHeight, pageW - margin, y + rowHeight);
                y += rowHeight;
              }
              if (capped) {
                y += 6;
                doc.setFontSize(7);
                doc.setTextColor(120, 120, 120);
                doc.text(t('Report.PdfTruncatedNote') || `First ${MAX_ANDROID_PDF_ROWS} of ${totalRows} rows. Use CSV for full report.`, margin, y);
                doc.setTextColor(0, 0, 0);
              }
              const fileName = `report_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.pdf`;
              const base64 = doc.output('datauristring').split(',')[1];
              await Filesystem.writeFile({ path: fileName, data: base64, directory: Directory.Cache });
              const { uri } = await Filesystem.getUri({ path: fileName, directory: Directory.Cache });
              if (typeof sessionStorage !== 'undefined') sessionStorage.setItem('skipResumeAlert', '1');
              await Share.share({ url: uri, title: t('Report.Export') || 'Export', dialogTitle: t('Report.Export') || 'Export' });
              const successMsg = capped
                ? (t('Report.ExportSuccessFirstOf') || 'Report exported (first {{first}} of {{total}} logs). Use CSV for full data.').replace('{{first}}', String(MAX_ANDROID_PDF_ROWS)).replace('{{total}}', String(totalRows))
                : `${t('Report.ExportSuccess') || 'Export success'} (${totalRows} logs).`;
              androidDeferredAfterIntent(successMsg);
            } catch (err) {
              if (typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
              console.error('[Report Export] PDF export error:', err);
              Swal.fire({ title: t('Report.Export') || 'Export', text: t('Report.ExportError') || 'Failed to export PDF.', icon: 'error' });
            }
          });
          break;
        }
        try {
          const project = projects.find(p => normalizeProjectId(p.id) === normalizeProjectId(selectedId));
          const doc = new jsPDF('p', 'mm', 'a4');
          const pageW = doc.internal.pageSize.getWidth();
          const margin = 10;
          const colWidths = [50, 40, 35, 52];
          const rowHeight = 7;
          let y = margin;
          doc.setFontSize(14);
          doc.text(t('Report.Export') || 'Report', margin, y);
          y += 10;
          doc.setFontSize(10);
          if (project) doc.text(`${t('Report.MyProjects') || 'Project'}: ${project.title}`, margin, y);
          y += 6;
          doc.text(`${format(new Date(filter.start), 'yyyy-MM-dd')} – ${format(new Date(filter.end), 'yyyy-MM-dd')}`, margin, y);
          y += 10;
          const headers = ['Unit', t('Report.Load'), t('Report.Battery'), t('Report.Time')];
          doc.setFontSize(8);
          doc.setFillColor(240, 240, 240);
          doc.rect(margin, y, pageW - 2 * margin, rowHeight, 'F');
          headers.forEach((h, i) => {
            doc.text(h, margin + (i === 0 ? 2 : colWidths.slice(0, i).reduce((a, b) => a + b, 0) + 2), y + 5);
          });
          doc.setDrawColor(200, 200, 200);
          let colX = margin;
          colWidths.forEach((w) => { doc.line(colX, y, colX, y + rowHeight); colX += w; });
          doc.line(margin, y + rowHeight, pageW - margin, y + rowHeight);
          y += rowHeight;
          const maxY = doc.internal.pageSize.getHeight() - margin;
          for (let i = 0; i < logData.length; i++) {
            if (y + rowHeight > maxY) {
              doc.addPage();
              y = margin;
              doc.setFillColor(240, 240, 240);
              doc.rect(margin, y, pageW - 2 * margin, rowHeight, 'F');
              headers.forEach((h, ii) => {
                doc.text(h, margin + (ii === 0 ? 2 : colWidths.slice(0, ii).reduce((a, b) => a + b, 0) + 2), y + 5);
              });
              colX = margin;
              colWidths.forEach((w) => { doc.line(colX, y, colX, y + rowHeight); colX += w; });
              doc.line(margin, y + rowHeight, pageW - margin, y + rowHeight);
              y += rowHeight;
            }
            const r = getReportRows(logData)[i];
            const row = [r.Unit.slice(0, 24), r.Load.slice(0, 14), r.Battery.slice(0, 8), r.Time.slice(0, 19)];
            row.forEach((cell, ii) => {
              doc.text(cell, margin + (ii === 0 ? 2 : colWidths.slice(0, ii).reduce((a, b) => a + b, 0) + 2), y + 5);
            });
            colX = margin;
            colWidths.forEach((w) => { doc.line(colX, y, colX, y + rowHeight); colX += w; });
            doc.line(margin, y + rowHeight, pageW - margin, y + rowHeight);
            y += rowHeight;
          }
          const fileName = `report_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.pdf`;
          if (platformType === 'web') {
            const blob = doc.output('blob');
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            a.click();
            URL.revokeObjectURL(url);
            console.log('[Report Export] PDF Web download triggered', fileName);
          } else {
            const base64 = doc.output('datauristring').split(',')[1];
            await Filesystem.writeFile({ path: fileName, data: base64, directory: Directory.Documents });
            Swal.fire({ title: t('Report.Export') || 'Export', text: `${t('Report.ExportSuccess')} (${logData.length} logs).`, icon: 'success' });
          }
        } catch (err) {
          console.error('[Report Export] PDF export error:', err);
          Swal.fire({ title: t('Report.Export') || 'Export', text: t('Report.ExportError') || 'Failed to export PDF.', icon: 'error' });
        }
        break;
      }
      case t('Report.Email'): {
        try {
          const project = projects.find(p => normalizeProjectId(p.id) === normalizeProjectId(selectedId));
          const subject = 'Ron Stage Master Report' + (project?.title ? ` - ${project.title}` : '');
          const escapeCsv = (v: any) => {
            const s = v == null ? '' : String(v);
            if (/[",\r\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
            return s;
          };
          const reportRows = getReportRows(logData);
          const csvRows: string[] = ['Unit,Load,Battery,Time'];
          reportRows.forEach((r) => csvRows.push([r.Unit, r.Load, r.Battery, r.Time].map(escapeCsv).join(',')));
          const csvStr = '\uFEFF' + csvRows.join('\r\n');
          const fileName = `report_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.csv`;
          const bodyText = project?.title
            ? `${t('Report.AttachedReport') || 'Please find the report attached.'} ${project.title}, ${format(new Date(filter.start), 'yyyy-MM-dd')} – ${format(new Date(filter.end), 'yyyy-MM-dd')}, ${logData.length} ${t('Report.Rows') || 'rows'}.`
            : `${t('Report.AttachedReport') || 'Please find the report attached.'} ${logData.length} ${t('Report.Rows') || 'rows'}.`;

          const isNative = Capacitor.isNativePlatform();
          if (isNative) {
            try {
              const available = await EmailComposer.isAvailable();
              if (available) {
                let attachments: string[] = [];
                if (platformType === 'android') {
                  await Filesystem.writeFile({ path: fileName, data: csvStr, directory: Directory.Cache, encoding: Encoding.UTF8 });
                  const { uri } = await Filesystem.getUri({ path: fileName, directory: Directory.Cache });
                  attachments = [uri];
                } else {
                  const base64Csv = btoa(unescape(encodeURIComponent(csvStr)));
                  attachments = [`base64:${fileName}//${base64Csv}`];
                }
                if (platformType === 'android' && typeof sessionStorage !== 'undefined') sessionStorage.setItem('skipResumeAlert', '1');
                await EmailComposer.open({
                  subject,
                  body: bodyText,
                  isHtml: false,
                  attachments,
                });
                if (platformType === 'android') {
                  androidDeferredAfterIntent(t('Report.EmailOpened') || 'Email composer opened.');
                } else {
                  Swal.fire({ title: t('Report.Export') || 'Export', text: t('Report.EmailOpened') || 'Email composer opened.', icon: 'success' });
                }
              } else {
                openMailtoFallback(subject, logData);
              }
            } catch (pluginErr) {
              if (platformType === 'android' && typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
              console.warn('[Report Email] Plugin failed, using mailto:', pluginErr);
              openMailtoFallback(subject, logData);
            }
          } else {
            openMailtoFallback(subject, logData);
          }
        } catch (err) {
          if (platformType === 'android' && typeof sessionStorage !== 'undefined') sessionStorage.removeItem('skipResumeAlert');
          console.error('[Report Export] Email error:', err);
          Swal.fire({ title: t('Report.Export') || 'Export', text: t('Report.ExportError') || 'Failed to open email.', icon: 'error' });
        }
        break;
      }
      default:
        break;
    }
  }

  const handleChangeFilter = (field: string, value: boolean | Date) => {
    setFilter(v => ({ ...v, [field]: value }))
    console.log('date changed: ', field, value)
  }

  const handleRemove = () => {
    if (!selectedId) return;
    const pidNorm = normalizeProjectId(selectedId);
    Swal.fire({
      title: 'Delete Logs',
      text: 'Delete all logs for this project? This cannot be undone.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: t("Common.Confirm"),
      cancelButtonText: t("Common.Cancel"),
      heightAuto: false
    }).then((result) => {
      if (!result.value) return;
      setLoading(true);
      db.logs
        .filter((log: any) => normalizeProjectId(log.project_id) === pidNorm)
        .primaryKeys()
        .then((keys) => db.logs.bulkDelete(keys))
        .then(() => {
          setLogList(null);
          setLoading(false);
        })
        .catch((error) => {
          console.error('Failed to delete logs:', error);
          setLoading(false);
        });
    });
  }
  const handleRefresh = () => {
    setLoadStatus(true)
  }

  const selectedProject = projectList.find((p: IProject) => normalizeProjectId(p.id) === normalizeProjectId(selectedId));

  return (
    <CommonLayout>
      <div className="grid grid-cols-4 gap-2">
        <div className="flex flex-col gap-2 ml-0.5 min-w-0">
          <Text classes="w-full bg-primary px-4 py-1" label={t('Report.MyProjects')} />
          <div className="flex flex-col">
            {projectList.length > 0 && projectList.map((item: IProject, index: number) => {
              const isSelected = normalizeProjectId(item.id) === normalizeProjectId(selectedId);
              return (
                <ul
                  key={index}
                  className={`list-disc list-inside px-4 py-1 cursor-pointer ${isSelected ? 'ring-2 ring-primary rounded font-bold shadow-md' : ''}`}
                  onClick={() => setSelectedId(String(item.id))}
                >
                  <li>
                    <Text classes={isSelected ? 'text-primary font-bold' : 'text-primary'} label={item.title} />
                  </li>
                </ul>
              );
            })}
          </div>
        </div>
        <div className="col-span-3 flex flex-col px-6 gap-2">
          <>
              {selectedProject && (
                <div className="flex flex-row items-center gap-2 py-1 flex-wrap">
                  <Text label={t('Report.ShowingReports')} />
                  <span className="font-medium text-primary">{selectedProject.title}</span>
                </div>
              )}
              <div className="flex flex-row items-center gap-2 py-2">
                <Text label={`${t('Report.Export')}: `} />
                {ExportList.filter((item) => !(item as { hidden?: boolean }).hidden).map((item, key) => (
                  <div
                    key={key}
                    className="flex flex-row items-center gap-1"
                    onClick={() => handleExport(item.title)}
                  >
                    <IonIcon src={item.icon} color="primary" />
                    <Text label={item.title} />
                  </div>
                ))}
              </div>
              <hr className="w-full border border-gray-300" />
              <div className="flex flex-col gap-2">
                <Text label={`${t('Common.Filter')}:`} />
                <div className="flex flex-row items-center gap-4">
                  <div className='flex flex-row justify-center items-center gap-2' onClick={() => handleChangeFilter('ok', !filter.ok)}>
                    <IonToggle checked={filter.ok} onChange={() => { console.log('') }} />
                    <Text label={t('Common.Okay')} />
                  </div>
                  <div className='flex flex-row justify-center items-center gap-2' onClick={() => handleChangeFilter('overload', !filter.overload)}>
                    <IonToggle checked={filter.overload} onChange={() => { console.log('') }} />
                    <Text label={t('Common.Overload')} />
                  </div>
                  <div className='flex flex-row justify-center items-center gap-2' onClick={() => handleChangeFilter('danger', !filter.danger)}>
                    <IonToggle checked={filter.danger} onChange={() => { console.log('') }} />
                    <Text label={t('Common.Danger')} />
                  </div>
                  <div className='flex flex-row justify-center items-center gap-2' onClick={() => handleChangeFilter('underload', !filter.underload)}>
                    <IonToggle checked={filter.underload} onChange={() => { console.log('') }} />
                    <Text label={t('Common.Underload')} />
                  </div>
                  <div className='flex flex-row justify-center items-center gap-2' onClick={() => handleChangeFilter('err', !filter.err)}>
                    <IonToggle checked={filter.err} onChange={() => { console.log('') }} />
                    <Text label={t('Common.TrErr')} />
                  </div>
                </div>
                <div className="flex flex-row items-center gap-8">
                  <div className="flex flex-row items-center gap-2">
                    <Text label={t('Common.From')} />
                    <input
                      type="date"
                      value={format(new Date(filter.start).toISOString(), 'yyyy-MM-dd')}
                      className="outline-none border border-dark rounded p-1"
                      onChange={(e) => handleChangeFilter('start', new Date(getTime(e.target.value) + new Date().getTimezoneOffset() * 60 * 1000))}
                    />
                  </div>
                  <div className="flex flex-row items-center gap-2">
                    <Text label={t('Common.To')} />
                    <input
                      type="date"
                      value={format(new Date(filter.end), 'yyyy-MM-dd')}
                      className="outline-none border border-dark rounded p-1"
                      onChange={(e) => handleChangeFilter('end', new Date(getTime(e.target.value) + new Date().getTimezoneOffset() * 60 * 1000))}
                    />
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <div className={`p-2 w-max rounded flex justify-center items-center ${logList ? 'bg-danger' : 'bg-red-300'}`}
                  onClick={() => handleRemove()}
                >
                  <IonIcon icon={trashSharp} color="light" />
                </div>
                <div
                  className={`p-2 w-max rounded flex justify-center items-center bg-primary`}
                  onClick={() => handleRefresh()}
                >
                  <IonIcon icon={refreshSharp} color="light" />
                </div>
              </div>
              <Spinner visible={loading} />
              <ReportTable />
          </>
        </div>
      </div>
    </CommonLayout>
  )
}

export default Report;
