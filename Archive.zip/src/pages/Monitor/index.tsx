import React, { FC, useEffect, useRef, useState } from "react";
import CommonLayout from "../../Layout/CommonLayout";
import './index.css';
import { IGroup, ILC } from "../../helper/types";

import useAppData from "../../hooks/useAppData";
import MonitorView from "../../components/Monitor/MonitorView";
import MonitorList from "../../components/Monitor/MonitorList";
import MonitorProg from "../../components/Monitor/MonitorProg";
import MonitorStop from "../../components/Monitor/MonitorStop";
import Text from "../../components/Text";
import { useTranslation } from "react-i18next";
import GroupActionModal from "../../components/Modals/GroupActionModal";
import SuccessModal from "../../components/Modals/SuccessModal";
// import * as database from '../../database'
import { db } from "../../db";
import Swal from "sweetalert2";
import { format, getTime } from "date-fns";
import useGroupOperations from "../../helper/db/groups";
import useFunctions from "../../hooks/useFunctions";
import { fire_error, getLCsByGroup, normalizeProjectId, strToFloat } from "../../helper/functions";
import { toast } from "react-toastify";

const MonitorModals = {
  GroupAction: 'action',
  Zero: 'zero',
}
const Monitor: FC = () => {
  const { setGroupTare, setGroupZero } = useGroupOperations();
  const {
    curProject,
    lcs,
    monitorStatus,
    bleConnected,
    logs,
    LCMax: lc_max,
    groups,
    lc_wind_alerts,
    liveLC,
    projects,
    isCreatingLCs,
    tareStatus,
    updateTareStatus,
    updateErrStr,
    updateLCs,
    updateGroups,
    updateTotalWeightHtml,
    updateWarnList,
    updateLCWindAlerts,
    updateLiveLC,
    load_lcs,
    updateCurProject,
    updateProjects,
  } = useAppData()
  const { t } = useTranslation()

  const {
    f_load_groups,
    f_load_lcs,
    f_load_projects,
    f_update_project_last_change,
    f_update_project_image_size,
    f_update_project_image_position,
    f_load_cells,
    play_beep,
    f_get_units_multiply

  } = useFunctions()

  const weighing = {
    status: 0,
    net: 0,
    gross: 0,
    tare: 0,
  }

  const [groupList, setGroupList] = useState<IGroup[]>([])

  const [dbHanlder, setDBHandler] = useState(null)

  const [list, setListData] = useState<ILC[]>([]);
  const [prevState, setPrevState] = useState<Partial<ILC>[]>([]);
  const [battState, setBattState] = useState<boolean>(false)
  const [maxStatus, setMaxStatus] = useState<boolean>(false)
  const [loadStatus, setLoadStatus] = useState<boolean>(true)
  const [warning, setWarning] = useState<boolean>(false)

  // const [selected, setSelected] = useState<IGroup | null>(null)
  const selectedRef = useRef<IGroup | null>()
  const [visibleModal, setVisibleModal] = useState<string>('');
  const [success, setSuccess] = useState<{ title: string; subtitle: string; } | null>(null)
  const [count, setCount] = useState(0);
  const [lcMonitorErrors, setLCMonitorErrors] = useState([]);
  const [lastAlert, setLastAlert] = useState<number>(getTime(new Date()));
  const [alertsArray, setAlertsArray] = useState<any>([])
  const [lcsOverloadArray, setLcsOverloadArray] = useState<any>([])
  const [totalSumOverload, setTotalSumOverload] = useState<any>([])
  const [preOverload, setPreOverload] = useState<any>([])
  const alertsArrayRef = useRef<any>(alertsArray)
  const lcsOverloadArrayRef = useRef<any>(lcsOverloadArray)
  const totalSumOverloadRef = useRef<any>(totalSumOverload)
  const preOverloadRef = useRef<any>(preOverload)
    const isProcessingRef = useRef<boolean>(false);
  const lastLcsHashRef = useRef<string>('');

  useEffect(() => {
    // Impementing the setInterval method
    const interval = setInterval(() => {
      setCount(prev => prev + 1)
    }, 1000)

    // Clearing the interval
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (isProcessingRef.current) return;
      const lcsHash = JSON.stringify(lcs.map(lc => ({ id: lc.id, value: lc.value })));
    if (lcsHash === lastLcsHashRef.current && count === 0) return;
    lastLcsHashRef.current = lcsHash;
    isProcessingRef.current = true;
    f_monitor_total_sum(lcs).finally(() => {
      isProcessingRef.current = false;
    });
  }, [count, lcs, liveLC])

  useEffect(() => {
    if (curProject) {
      f_load_lcs()
    }
  }, [curProject])

  const f_monitor_total_sum = async (lcList: ILC[]) => {
    let value = ''
    if (!curProject.id || lcList.length < lcs.length) {
      updateTotalWeightHtml('<span class="text-xs font-bold bg-danger text-white px-1.5 py-0.5 rounded">Tr. Err</span>');
      value = 'Tr.Err'
    }
    let t = 0;
    for (const lc of lcList) {
      const useTare = lc.status_tare && tareStatus && lc.weightnotare != null && lc.weightnotare !== '';
      const displayVal = useTare ? lc.weightnotare : lc.value;
      await fire_overload(lc.id, displayVal, lc.overload, 'lcs', lc.underload);
      let v: any = await (useTare ? lc.weightnotare : lc.value);
      if (v && v.toString() === `Tr.Err`) {
        updateTotalWeightHtml('<span class="text-xs font-bold bg-danger text-white px-1.5 py-0.5 rounded">Tr. Err</span>');
        value = 'Tr.Err'
      }
      else {
        v = parseFloat(v);

        const p = parseFloat(lc.psw ?? '0');
        t += v;
      }
    }
    if (value === 'Tr.Err') {
      await updateTotalWeightHtml('<span class="text-xs font-bold bg-danger text-white px-1.5 py-0.5 rounded">Tr. Err</span>');
      value = 'Tr.Err'
    } else {
      if (t < 0) {
        t = 0;
      }
      await updateTotalWeightHtml(curProject.units?.toLowerCase() !== "m.ton" ? t.toFixed(0) : t.toFixed(3));
    }
    if (value !== 'Tr.Err')
      value = (curProject.units?.toLowerCase() !== "m.ton" ? t.toFixed(0) : t.toFixed(3))
    await fire_overload('totalSum', value, curProject.total_overload, 'totalSum')
    if (Number(curProject.pre_overload) !== 100) {
      await fire_overload('preOverload', value, ((Number(curProject.total_overload) / 100) * (Number(curProject.pre_overload))), 'preOverload')
    }
  }
  useEffect(() => {
    show_overload_alert(alertsArray, 'group')
  }, [alertsArray])
  useEffect(() => {
    alertsArrayRef.current = alertsArray;
  }, [alertsArray]);

  useEffect(() => {
    show_overload_alert(lcsOverloadArray, 'lcs')
  }, [lcsOverloadArray])

  useEffect(() => {
    lcsOverloadArrayRef.current = lcsOverloadArray
  }, [lcsOverloadArray])

  useEffect(() => {
    show_overload_alert(totalSumOverload, 'totalSum')
  }, [totalSumOverload])
  useEffect(() => {
    totalSumOverloadRef.current = totalSumOverload
  }, [totalSumOverload])
  useEffect(() => {
    show_overload_alert(preOverload, 'preOverload')
  }, [preOverload])
  useEffect(() => {
    preOverloadRef.current = preOverload
  }, [preOverload])
  const fire_overload = async (item_id: any, weight: any, overload: any, type: string, underload?: any, pre_overload?: any) => {
    const currentTime = Date.now();
    const setAlerts = (type === 'lcs' ? setLcsOverloadArray : (type === 'group' ? setAlertsArray : (type === 'preOverload' ? setPreOverload : setTotalSumOverload)));
    const currentRef = (type === 'lcs' ? lcsOverloadArrayRef : (type === 'group' ? alertsArrayRef : (type === 'preOverload' ? preOverloadRef : totalSumOverloadRef)));
    setAlerts((prevAlerts: any) => {
      const currentAlerts = currentRef.current;
      if (JSON.stringify(prevAlerts) === JSON.stringify(currentAlerts) && currentAlerts.length > 0) {
        const existingAlert = currentAlerts.find((alert: any) => alert.id === item_id);
        if (existingAlert) {
          const weightNum = Number(weight);
          const overloadNum = Number(overload);
          const existingWeightNum = Number(existingAlert.weight);
          const existingOverloadNum = Number(existingAlert.overload);
              if (existingWeightNum === weightNum && 
              existingOverloadNum === overloadNum &&
              existingAlert.ifNeedShow === ((!isNaN(weightNum) && weightNum > overloadNum) || (underload && weightNum < Number(underload)))) {
            return prevAlerts; // No change, return previous to prevent update
          }
        }
      }
      
      let ifChange = false;
      let updatedAlerts = [...prevAlerts];
      if (updatedAlerts.length > 0) {
        const existingAlertIndex = updatedAlerts.findIndex((alert: any) => alert.id === item_id);
        if (existingAlertIndex === -1) {
          if ((!isNaN(weight) && (Number(weight)) > overload) || (underload && (Number(weight)) < underload)) {
            updatedAlerts.push({
              id: item_id,
              isShow: false,
              weight: weight,
              overload: weight > overload ? overload : underload,
              isOverload: (!isNaN(weight) && (Number(weight)) > overload),
              ifNeedShow: true
            });
            ifChange = true;
          } else {
            updatedAlerts.push({
              id: item_id,
              isShow: false,
              weight: weight,
              overload: weight > overload ? overload : underload,
              isOverload: (!isNaN(weight) && (Number(weight)) > overload),
              ifNeedShow: false
            });
            ifChange = true;
          }
        } else {
          const existingAlert = updatedAlerts[existingAlertIndex];
          if ((!isNaN(weight) && (Number(weight)) > overload) || (underload && (Number(weight)) < underload)) {
            if (existingAlert.ifNeedShow && existingAlert.isShow) {
              if ((Number(existingAlert.weight)) !== (Number(weight)) || ((!isNaN(weight) && (Number(weight)) > (Number(overload)) && (Number(existingAlert.overload)) !== (Number(overload))) || ((Number(weight)) < (Number(underload)) && (Number(existingAlert.overload)) !== (Number(overload))))) {
                updatedAlerts[existingAlertIndex] = {
                  ...existingAlert,
                  weight: weight,
                  overload: (Number(weight)) > (Number(overload)) ? overload : underload,
                  isOverload: (!isNaN(weight) && (Number(weight)) > overload),
                };
                ifChange = true;
              }
            } else if (existingAlert.ifNeedShow && !existingAlert.isShow) {
              if (!existingAlert.lastAlert || ((currentTime - existingAlert.lastAlert) / 1000) >= 10) {
                updatedAlerts[existingAlertIndex] = {
                  ...existingAlert,
                  isShow: true,
                  weight: weight,
                  overload: weight > overload ? overload : underload,
                  isOverload: (!isNaN(weight) && (Number(weight)) > overload),
                  lastAlert: currentTime,
                  ifNeedShow: true
                };
                ifChange = true;
              }
            } else if (!existingAlert.ifNeedShow && !existingAlert.isShow) {
              updatedAlerts[existingAlertIndex] = {
                ...existingAlert,
                isShow: true,
                weight: weight,
                overload: (Number(weight)) > (Number(overload)) ? overload : underload,
                isOverload: (!isNaN(weight) && (Number(weight)) > overload),
                ifNeedShow: true
              };
              ifChange = true;
            }
          } else {
          if (existingAlert.ifNeedShow !== false) {
            updatedAlerts[existingAlertIndex] = {
              ...existingAlert,
              ifNeedShow: false,
              isShow: false
            };
            ifChange = true;
          }
          }
        }
      } else {
        if ((!isNaN(weight) && (Number(weight)) > (Number(overload))) || ((Number(underload)) && (Number(weight)) < (Number(underload)))) {
          updatedAlerts = [{
            id: item_id,
            isShow: true,
            weight: weight,
            overload: (Number(weight)) > (Number(overload)) ? overload : underload,
            isOverload: (!isNaN(weight) && (Number(weight)) > overload),
            ifNeedShow: true
          }];
          ifChange = true;
        } else {
          updatedAlerts = [{
            id: item_id,
            isShow: false,
            weight: weight,
            overload: (Number(weight)) > (Number(overload)) ? overload : underload,
            isOverload: (!isNaN(weight) && (Number(weight)) > overload),
            ifNeedShow: false
          }];
          ifChange = true;
        }
      }
      return ifChange ? updatedAlerts : prevAlerts;
    });
  }
  const updateAlertsArray = async (alertId: any, type: string) => {
    const current_array = (type === 'lcs' ? lcsOverloadArrayRef.current : (type === 'group' ? alertsArrayRef.current : (type === 'preOverload' ? preOverloadRef.current : totalSumOverloadRef.current)))
    const updatedAlertsArray = current_array.map((alert: any) => {
      if (alert.id === alertId) {
        return {
          ...alert,
          lastAlert: Date.now(),
          isShow: false,
          ifNeedShow: true
        };
      }
      return alert;
    });
    (type === 'lcs' ? await setLcsOverloadArray(updatedAlertsArray) : (type === 'group' ? await setAlertsArray(updatedAlertsArray) : (type === 'preOverload' ? await setPreOverload(updatedAlertsArray) : await setTotalSumOverload(updatedAlertsArray))))
  };
  const show_overload_alert = async (alerts: any, type: string) => {
    if (isCreatingLCs) return;
    const arrayToIterate = (type === 'lcs' ? liveLC : (type === 'group' ? groups : projects));
    let ifChange = false;
    let toUpdate = false
    let click = false

    const u = curProject?.units?.toLowerCase().replace('.', ''); // for m.ton;
    const fx = (u == "mton") ? 3 : 0;

    if (alerts && alerts.length > 0) {
      const updatedAlerts = alerts.map((alert: any) => {
        if (isNaN(alert.weight)) {
          if (toast.isActive(alert.id)) {
            toast.dismiss(alert.id);
          }
        }
        let updatedAlert = alert;
        if (type === 'lcs') {
          if (liveLC.length === 0) {
            lcs.forEach((lc) => {
              if (toast.isActive(lc.id)) {
                toast.dismiss(lc.id);
              }
            })
          }
        }
        if (lcs.length > liveLC.length) {
          lcs.filter(alert => !liveLC.some(liveAlert => liveAlert.id === alert.id))
            .forEach(alert => {
              if (toast.isActive(alert.id)) {
                toast.dismiss(alert.id);
              }
            });
        }
        arrayToIterate.forEach(async (b) => {
          if (b.id == alert.id || ((type === 'totalSum' || type === 'preOverload') && b.id === curProject.id)) {
            if (alert.isShow && alert.ifNeedShow) {
              const w = parseFloat(alert.weight);
              const ov = parseFloat(alert.overload);
              const isDangerOverload = !isNaN(w) && !isNaN(ov) && ov > 0 && w >= ov * 1.3;
              let o: string;
              if (type === 'lcs' && b.id >= 1 && b.id <= 10 && alert.weight > alert.overload) {
                o = "OVERSPEED";
              } else if (type === 'totalSum') {
                o = isDangerOverload ? "DANGER" : "TOTAL OVERLOAD";
              } else if (type === 'preOverload') {
                o = "PRE OVERLOAD";
              } else {
                const isOver = alert.isOverload !== undefined ? alert.isOverload : (alert.weight > alert.overload);
                o = isOver ? (isDangerOverload ? "DANGER" : "OVERLOAD") : "UNDERLOAD";
              }
              const isOverLabel = o === "DANGER" || o === "OVERLOAD" || o === "TOTAL OVERLOAD";
              const toastExists = toast.isActive(alert.id);
              if (toastExists) {
                toast.update(alert.id, {
                  render: (
                    <div>
                      <h4>{o}!</h4>
                      <p>{`${(type === 'lcs' ? "Lc: " : (type === 'group' ? "Group: " : ((type === 'totalSum' || type === 'preOverload') ? '' : "Windmeter")))} ${(type !== 'totalSum' && type !== 'preOverload') ? alert.id : ''}`}{`${o === 'OVERSPEED' ? ' | Speed: ' : ((type === 'totalSum' || type === 'preOverload') ? 'Weight: ' : ' | Weight: ')}`} {parseFloat(alert.weight).toFixed(fx)} {`${o === 'OVERSPEED' ? " | Capacity: " : (isOverLabel ? ' | Overload: ' : ' | Underload: ')}`} {parseFloat(alert.overload).toFixed(fx)}</p>
                    </div>
                  ),
                  autoClose: false,
                  closeOnClick: true
                });
              }
              else {

                await toast.error(
                  <div>
                    <h4>{o}!</h4>
                    <p>{`${(type === 'lcs' ? "Lc: " : (type === 'group' ? "Group: " : ((type === 'totalSum' || type === 'preOverload') ? '' : "Windmeter")))} ${(type !== 'totalSum' && type !== 'preOverload') ? alert.id : ''}`}{`${o === 'OVERSPEED' ? ' | Speed: ' : ((type === 'totalSum' || type === 'preOverload') ? 'Weight: ' : ' | Weight: ')}`} {parseFloat(alert.weight).toFixed(fx)} {`${o === 'OVERSPEED' ? " | Capacity: " : (isOverLabel ? ' | Overload: ' : ' | Underload: ')}`} {parseFloat(alert.overload).toFixed(fx)}</p>
                  </div>,
                  {
                    toastId: alert.id,
                    onClose: async (reason) => {
                      if (reason) {
                        click = true
                        await updateAlertsArray(alert.id, type)
                      }
                      toUpdate = true;
                    },
                    autoClose: false,
                    closeOnClick: true,
                  }
                );
                play_beep(4)
                if (toUpdate === true) {
                  ifChange = true;
                  if (click) {
                    updatedAlert = {
                      ...alert,
                      lastAlert: Date.now(),
                      isShow: false,
                      ifNeedShow: true
                    }
                  }
                  else {
                    updatedAlert = {
                      ...alert,
                      lastAlert: Date.now(),
                      isShow: false,
                      ifNeedShow: false
                    }
                  }
                }
              }
            }
            else {
              if (toast.isActive(alert.id)) {
                toast.dismiss(alert.id);
              }
            }
          }
        });
        return updatedAlert;
      });
            if (ifChange) {
        const currentRef = (type === 'lcs' ? lcsOverloadArrayRef : (type === 'group' ? alertsArrayRef : (type === 'preOverload' ? preOverloadRef : totalSumOverloadRef)));
        const currentArray = currentRef.current;
        const arraysEqual = JSON.stringify(currentArray) === JSON.stringify(updatedAlerts);
        if (!arraysEqual) {
          type === 'lcs' ? await setLcsOverloadArray(updatedAlerts) : (type === 'group' ? await setAlertsArray(updatedAlerts) : (type === 'preOverload' ? await setPreOverload(updatedAlerts) : await setTotalSumOverload(updatedAlerts)))
        }
      }
    }
  }
  const handleMoveLC = async (lcItem: ILC) => {
    updateLCs(lcItem);
    await db.lcs.put(lcItem);
  }

  const handleReset = async (reset: boolean) => {
    if (lcs.length > 0) {
      const lcIds = lcs.map(item => item.lc_id)
      if (reset) {
        setPrevState(lcs);
        // Do not update state to 0,0; home is applied only at display time in MonitorView
        const nextProject = { ...curProject, lc_display_mode: 'home' as const };
        updateCurProject(nextProject);
        updateProjects(projects.map(p => p.id === curProject.id ? { ...p, lc_display_mode: 'home' } : p));
        await db.projects.update(curProject.id, { lc_display_mode: 'home' });
      } else {
        if (prevState.length > 0) {
          const updated = lcs.map(item => {
            if (lcIds.includes(item.lc_id)) {
              const findItem = prevState.find(pItem => pItem.lc_id === item.lc_id)
              return { ...item, ...findItem };
            } else
              return item
          })
          updateLCs(updated)
          await db.lcs.bulkPut(updated)
        } else {
          await load_lcs();
        }
        const nextProject = { ...curProject, lc_display_mode: 'user' as const };
        updateCurProject(nextProject);
        updateProjects(projects.map(p => p.id === curProject.id ? { ...p, lc_display_mode: 'user' } : p));
        await db.projects.update(curProject.id, { lc_display_mode: 'user' });
      }
    }
  }

  const contentView = () => {
    switch (monitorStatus) {
      case 'view':
        return (
          <MonitorView
            data={lcs}
            max={maxStatus}
            load={loadStatus}
            tare={tareStatus}
            onMoveLC={handleMoveLC}
            onReset={handleReset}
          />
        )
      case 'list':
        return (<>
          <MonitorList data={lcs} />
        </>)
      case 'prog':
        return (<>
          <MonitorProg
            data={lcs}
            unit={curProject.units || ''}
            tare={tareStatus}
          />
        </>)
      case 'stop':
        return (<>
          <MonitorStop
            data={lcs}
            unit={curProject.units || ''}
            max={maxStatus}
            tare={tareStatus}
          />
        </>)
      default:
        break;
    }
  }

  const handleGroup = (group: IGroup) => {
    if (!unique_group_lcs(group.id)) {
      fire_error('This group contain non unique load cells');
      return false;
    }
    if (turned_off_Devices(group.id)) {
      fire_error('This group contains non-transmitting load cells')
      return false
    }

    if (bleConnected) {
      selectedRef.current = group
      setVisibleModal(MonitorModals.GroupAction)
    } else {
      updateErrStr(t('Msg.ErrConnectPRR'))
    }
  }
  const updateSumByGroup = async () => {
    if (curProject === null) {
      return;
    }
    groups.forEach(group => {
      let count: any = 0
      lcs.forEach(lc => {
        const currentGroups = lc.groups?.split(',')
        if (currentGroups && currentGroups.length > 0) {
          currentGroups.forEach(async (groupId) => {
            if (groupId === group.id) {
              if (lc.value && lc.value !== 'Tr.Err' && count !== 'Tr.Err') {
                const useTare = lc.status_tare && tareStatus;
                count += useTare ? (Number(lc.weightnotare)) : Number(lc.value);
              }
              if (!isNaN(count) && Number(count) < 0) {
                count = 0
              }
              if (lc.value === 'Tr.Err') {
                count = 'Tr.Err'
              }
              await fire_overload(group.id, count, group.overload, 'group');
              const filteredGroups = groups.filter((grp) => grp.id !== group.id);
              const filteredCurrentGroup = groups.filter((grp) => grp.id === group.id);
              filteredCurrentGroup[0].sum = count
              const updatedGrooupp = [...filteredGroups, ...filteredCurrentGroup]
              const sortedGroups = [...updatedGrooupp].sort((a, b) => {
                const idA = parseInt(a.id || '0');
                const idB = parseInt(b.id || '0');
                return idA - idB;
              });
              updateGroups(sortedGroups)
            }
          });
        }
      });
    });
  }
  useEffect(() => {
    const activeUpdateSumByGroup = async () => {
      await updateSumByGroup()
    }
    activeUpdateSumByGroup()
  }, [liveLC])

  const handleGroupAction = async (type: string) => {
    let ifBigger = true
    if (!selectedRef.current) return
    const groupShownId = selectedRef.current.id
    switch (type) {
      case 'tare':
        if (!groupShownId) return
        if (selectedRef.current?.tare !== 'true') {
          // when clicked tare
          let tare_ok = true
          lcs.forEach(lc => {
            const g = lc.groups?.split(',')
            const lcId = lc.id
            if (g?.includes(groupShownId)) {
              const live = liveLC.find(item => item.id === lcId)
              const v = strToFloat(live?.value) + strToFloat(live?.zero)
              if (v <= 0) {
                tare_ok = false
                ifBigger = false
              }
            }
          })
          if (tare_ok) {
            await tare_group(groupShownId)
            const onOk = tare_on(true);
            if (onOk) {
              setSuccess({
                title: t('Monitor.Modal.TareMode'),
                subtitle: t('Monitor.Modal.TareSubtitle')
              })
            } else {
              return
            }
          } else {
            if (!ifBigger) { updateErrStr("One or more of your LC's load <= 0") }
            else { updateErrStr('You must select at least one group in tare mode. doubletap the group name and then click "tare" button') }

          }
        } else {
          untare_group(groupShownId)
        }

        setVisibleModal('')
        break;
      case 'zero':
        if (selectedRef.current && selectedRef.current.id) {
          const groupId = String(selectedRef.current.id)
          const inGroup = (item: ILC) => (item.groups?.split(',').map(g => g.trim()) ?? []).includes(groupId)
          const groupLcs = lcs.filter(lc => normalizeProjectId(lc.project_id) === normalizeProjectId(curProject.id) && inGroup(lc))
          const multiply = f_get_units_multiply('M.TON')
          const newZero = (item: ILC) => curProject.units !== 'M.TON' ? Number(String((Number(item.realval)) * (Number(multiply))) || '0') * -1 : (Number(String((Number(item.realval))))) * -1
          const updates: { key: any; changes: any }[] = []
          groupLcs.forEach(lc => {
            updates.push({
              key: lc.lc_id,
              changes: {
                zero: newZero(lc),
                realval: parseInt(lc.realval ?? '0'),
                psw: '0'
              }
            })
          })
          try {
            for (const { key, changes } of updates) {
              await db.lcs.update(key, changes);
            }
          } catch (err) {
            setVisibleModal('')
            updateErrStr(t('Monitor.Modal.ZeroSubtitle') || 'Zero failed.')
            return
          }
          const updatedLcsArray = lcs.map(item => {
            if (normalizeProjectId(item.project_id) !== normalizeProjectId(curProject.id) || !inGroup(item)) return item
            return { ...item, psw: 0, zero: newZero(item) }
          })
          updateLCs(updatedLcsArray)
        }
        setSuccess({
          title: `${t('Monitor.Modal.Zero')} ${selectedRef.current?.title}`,
          subtitle: t('Monitor.Modal.ZeroSuccessSubtitle', { group: selectedRef.current?.title })
        })
        setVisibleModal('')
        break;
      default:
        break;
    }
  }

  const handleCloseModal = () => {
    setVisibleModal('')
  }

  const update_project_image = async (project_id: any, image: any) => {
    try {
      await db.projects.update(project_id, { p_image: image });
      f_update_project_last_change()
    } catch (err) {
      console.error('Error updating row: ', err);
    }
  }

  const lc_show_max = () => {
    console.log("===lc_show_max===")
  }

  const handleTareAction = (type: string, groupShownId: string) => {
    if (type === 'tare')
      tare_group(groupShownId)
    else
      untare_group(groupShownId)
  }

  const tare_group = async (groupShownId: string) => {
    const matchingLCs = lcs.filter(lc => liveLC.some(live => live.id === lc.id));
    const projectIdNorm = normalizeProjectId(curProject.id);
    try {
      const toUpdate: ILC[] = []
      for (const lc_m of matchingLCs) {
        const g = lc_m?.groups?.split(',') ?? []

        if (g.includes(groupShownId)) {
          const live = liveLC.find(live => live.id === lc_m.id)
          if (!live) {
            continue;
          }
          // liveValue from buffer = (raw + zero) already = "weight with zero" in display. So tare = -that in M.TON (do NOT add zero again).
          const multiply = f_get_units_multiply('M.TON')
          const liveRealval = (live as any).realval ?? lc_m.realval
          const liveValue = (live as any).value ?? lc_m.value
          const weightWithZeroDisplay = Number(liveValue ?? liveRealval ?? 0)
          const weightWithZeroInMton = curProject.units !== 'M.TON'
            ? weightWithZeroDisplay * Number(multiply)
            : weightWithZeroDisplay
          const tareInMton = -weightWithZeroInMton
          const index = lcs.findIndex(x => x.id === lc_m.id);
          if (index >= 0) {
            const weightnotare = curProject.units === 'M.TON' ? '0.000' : '0'
            toUpdate.push({ ...lcs[index], tare: tareInMton, status_tare: true, weightnotare })
          }
        }
      }
      if (toUpdate.length > 0) {
        const updatedLcs = lcs.map(item => {
          const u = toUpdate.find(t => t.id === item.id && normalizeProjectId(t.project_id) === normalizeProjectId(item.project_id));
          return u ?? item;
        });
        updateLCs(updatedLcs);
      } else {
        void 0; // No LCs to update (e.g. no live data or group mismatch)
      }

      if (!selectedRef.current) {
        return;
      }

      const updatedGroup: IGroup = {
        ...selectedRef.current,
        tare: 'true',
      }
      selectedRef.current = updatedGroup
      updateGroups(updatedGroup)
    } catch (error) {
      console.error('[TARE] Error updating tare value:', error);
    }
  }

  const untare_group = async (groupShownId: string) => {
    const projectIdNorm = normalizeProjectId(curProject.id);
    try {
      // Do not turn off global tare mode when untaring one group; only tare_off (toolbar) does that
      const updates: { key: any; changes: any }[] = []
      const ids: number[] = []
      lcs.forEach((lc, index) => {
        const g = lc.groups?.split(',').map(item => parseInt(item, 10))
        if (g?.includes(parseInt(groupShownId))) {
          updates.push({
            key: { id: lc.id, project_id: curProject.id },
            changes: { status_tare: false, tare: '0' }
          })
          ids.push(index)
        }
      })
      if (ids.length > 0) {
        const updatedLcs = lcs.map((lc, idx) =>
          ids.includes(idx) ? { ...lc, status_tare: false, tare: 0, weightnotare: undefined } : lc
        );
        updateLCs(updatedLcs);
      }
      // Update groups in DB/Context
      if (!selectedRef.current) return
      const updatedGroup: IGroup = {
        ...selectedRef.current,
        tare: '',
      }
      selectedRef.current = updatedGroup
      updateGroups(updatedGroup)

    } catch (error) {
      console.log('Transaction ERROR: ' + error);
    }
    const updateGroup = groups.map(g => {
      if (g.id === groupShownId) {
        const { tare, ...rest } = g
        selectedRef.current = rest
        return rest
      }
      return g
    })

    updateGroups(updateGroup)
  }

  const unique_group_lcs = (group_id: string) => {
    // check if lcs in group are uinque for this group
    // that in order to prevent tare or zero groups
    // that the lc is showed in more than one group
    let unique = true;
    lcs.forEach(function (lc) {
      const g = lc.groups?.split(',').map(item => parseInt(item, 10))
      if (g?.includes(parseInt(group_id))) {
        if (g.length > 1) {
          unique = false;
        }
      }
    });
    return unique;
  }
  const turned_off_Devices = (group_id: string) => {
    let turned_off = false
    groups.forEach((group) => {
      if (group.id === group_id && group.sum === 'Tr.Err')
        turned_off = true
    })
    return turned_off;
  }

  const handleMaxStatus = (val: boolean) => {
    if (val)
      setLoadStatus(true)
    setMaxStatus(val)
  }

  const handleLoadStatus = (val: boolean) => {
    if (!val)
      setMaxStatus(false)
    setLoadStatus(val)
  }

  const tareStatusToggle = () => {
    if (tareStatus)
      tare_off()
    else
      tare_on();
  }

  const tare_on = (isTared = false) => {
    let go_tare = 0
    const taredGroupIds: string[] = []
    groups.forEach((group) => {
      if (group.tare === 'true') {
        go_tare = 1
        taredGroupIds.push(String(group.id))
      }
    })
    if (go_tare == 1 || isTared) {
      updateTareStatus(true)
      return true
    } else {
      updateTareStatus(false)
      fire_error('You must select at least one group in tare mode. doubletap the group name and then click "tare" button');
      return false
    }
  }

  const tare_off = async () => {
    updateTareStatus(false)
    const newGroups = groups.map((group) => ({ ...group, tare: '' }))
    updateGroups(newGroups)
    const clearedLcs = lcs.map((lc) => ({ ...lc, status_tare: false, tare: 0, weightnotare: undefined }))
    updateLCs(clearedLcs)
    return true
  }
  const handleGroupActionCall = async (type: string) => {
    await handleGroupAction(type)
  }

  return (
    <CommonLayout
      classes='p-2 gap-1'
      maxStatus={maxStatus}
      loadStatus={loadStatus}
      tareStatus={tareStatus}
      warning={warning}
      maxStatusToggle={handleMaxStatus}
      loadStatusToggle={handleLoadStatus}
      tareStatusToggle={tareStatusToggle}
      onWarning={setWarning}
      onDBHandler={setDBHandler}
      onTareAction={handleTareAction}
    >
      <div className='grid grid-cols-16 h-10 w-full'>
        {groups.map((item: IGroup, index: number) => {
            let v = parseFloat(item.sum ?? '')
            let o = parseFloat(item.overload);
            const p = v / o * 100;

            const u = curProject?.units?.toLowerCase().replace('.', '') //for m.ton;
            const fx = (u == "mton") ? 3 : 0;

            if (isNaN(v)) {
              v = 0;
            }
            if (isNaN(o)) {
              o = 0;
            }

            return (
              <div
                key={index}
                className={`flex flex-col border-l border-dark cursor-pointer ${index === groups.length - 1 && 'border-r'}`}
                onDoubleClick={() => handleGroup(item)}
              >
                <Text
                  classes={`
                  h-1/2  text-dark !text-xs flex items-center justify-center
                  ${v > o ?
                    'bg-danger !important text-danger'
                    :
                    `${p > 130 ?
                      'bg-warning'
                      :
                      `${item.sum ? 'bg-primary' : 'bg-primary'}`
                    }`
                  }
                  ${p > 1}
                `}
                  label={item.overload ? item.title : ''}
                />
                {bleConnected ?
                  <Text
                    classes={item.sum === "Tr.Err" ? 'text-xs font-bold bg-danger rounded w-max p-1' : ('h-1/2 bg-medium text-dark !text-xs flex items-center justify-center')}
                    label={item.sum !== undefined && item.sum !== null ?
                      (item.sum === "Tr.Err" ? "Tr.Err" : (!Number.isNaN(parseFloat(item.sum)) ? parseFloat(item.sum).toFixed(fx) : ''))
                      : ''}
                  />
                  :
                  <div className="h-1/2 w-full bg-medium text-center flex justify-center items-center">
                    <span className={`text-xs font-bold ${item.overload && 'bg-danger'} text-white px-1.5 rounded w-max`}>{item.overload ? t("Common.TrErr") : ''}</span>
                  </div>
                }
              </div>
            )
          })}
      </div>
      {contentView()}
      <GroupActionModal
        visible={visibleModal === MonitorModals.GroupAction}
        tare={tareStatus && !!(selectedRef.current && selectedRef.current?.tare === 'true')}
        onAction={(type) => {
          handleGroupActionCall(type);
        }}
        onClose={() => handleCloseModal()}
      />
      <SuccessModal
        visible={success ? true : false}
        title={success?.title || ''}
        message={success?.subtitle || ''}
        classes="gap-4"
        titleClasses='!text-3xl'
        onClose={() => setSuccess(null)}
      />
    </CommonLayout>
  )
}

export default Monitor;