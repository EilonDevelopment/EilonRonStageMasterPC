import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: "com.eilonengineering.ronstage",
  appName: 'RonStage',
  webDir: 'build',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    "BluetoothLe": {
      "displayStrings": {
        "scanning": "Scanning...",
        "cancel": "Cancel",
        "availableDevices": "Available Devices",
        "noDeviceFound": "No device found"
      }
    }
  }
};

export default config;
